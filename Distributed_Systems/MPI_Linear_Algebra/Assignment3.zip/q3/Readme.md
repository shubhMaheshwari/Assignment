# Conjugate Gradient: 
	Iterations: 320
	Time: 0.350245
# Gauss Elimination:
	Time: 1.543080

# Hence Conjugate Gradient is a faster method for Gauss Elimination for PSD




