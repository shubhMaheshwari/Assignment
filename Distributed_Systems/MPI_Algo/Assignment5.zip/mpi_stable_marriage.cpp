// Parallel Stable Marriage algorithm 

#include <stdio.h>
#include <stdlib.h> 
#include<math.h>
#include <mpi.h>

int N;
int men[100][100];
int women[100][100];
int Match[100];


int main(int argc, char **argv) 
{

	// Init
	int ierr;
	ierr = MPI_Init(&argc, &argv);
	if(ierr != MPI_SUCCESS) {
		printf("Error starting MPI program. Terminating. \n");
		MPI_Abort(MPI_COMM_WORLD, ierr);
	}

	// Get the rank
	int rank,num_process;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &num_process);


	if(rank==0){
		scanf("%d",&N); // Input Nodes
		printf("%d %d\n",N,num_process);
		// Men ranking women 
		for (int i = 0; i < N; ++i)
			for (int j = 0; j < N; ++j)
				scanf("%d",&men[i][j]);

		// Women Ranking men
		for (int i = 0; i < N; ++i)
			for (int j = 0; j < N; ++j)
				scanf("%d",&women[i][j]);

		if(num_process != 1 + 2*N){
			printf("Number of process should be equal to 1 + 2*N. Terminating. \n");
			MPI_Abort(MPI_COMM_WORLD,0);
		}
	}
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(men, 100 * 100, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(women, 100, MPI_INT, 0, MPI_COMM_WORLD);


    if(rank==0){
    	// Do Something

    	// Semd match llist
		MPI_Bcast(match, 100, MPI_INT, i, 0, MPI_COMM_WORLD);	// Sends preference lists

    }

    else{
    	// Do Something
		// REceive Match list
    }




	if(rank==0){
		printf("Match:");
		for(int i = 0; i < N; ++i)
			printf("Men:%d Women:%d",i, Match[i]);
		printf("\n");
	}
	 
	ierr = MPI_Finalize();
	if(ierr != MPI_SUCCESS) {
		printf("Error Terminating MPI program. Terminating. \n");
		MPI_Abort(MPI_COMM_WORLD, ierr);
	}

	return 0;
}