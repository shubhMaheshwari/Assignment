#!/bin/bash

g++ main.cpp 
./aout $1 $2