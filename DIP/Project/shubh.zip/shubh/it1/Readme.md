- First need to extract the cvx zip file
- cd into it & run cvx_setup
- Then you can run final.m or video.m or panorama.m

final.m is maim function
nrdc.mexw64 is binary file for NRDC implementation
NewChannelAns calculates transform functions