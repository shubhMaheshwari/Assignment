*Currently code is designed for Transforming images to the fi of ref image.
*Only one image's change can be propogated right now.

-first need to extract the cvx zip file
-cd into it & run cvx_setup
-then you can run final.m

final.m---> maim function
nrdc.mex-->executable file for NRDC implementation
NewChannelAns-->calculate transform functions