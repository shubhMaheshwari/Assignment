import numpy as np 
import cv2

cv2.imread('./rose.jpeg')


# def top_k_color(im,k):
