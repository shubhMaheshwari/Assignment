% Using Dot product to match the number dialed 

% For police number 
result = Eavesdrop('./Police.ogg')

% For the given number  9515733002

result = Eavesdrop('./9515733002.ogg');
sprintf('%10d\n',result ) 