#include "main.h"

const color_t COLOR_RED = { 25, 120, 75 };
const color_t COLOR_ORANGE = { 136, 10, 75 };
const color_t COLOR_GREEN = { 15, 211, 14 };
const color_t COLOR_BLUE = { 0, 3, 158 };
const color_t COLOR_BROWN = { 210, 180, 140 };
const color_t COLOR_GREY = { 210, 210, 210 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_WHITE = { 255,222,173 };
const color_t COLOR_BACKGROUND = { 242, 241, 239 };
