#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_BLUE = { 100, 100, 255 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 255, 255, 255 };
const color_t COLOR_YELLOW = { 200, 200, 100 };
const color_t COLOR_BROWN = {210, 105, 30};
