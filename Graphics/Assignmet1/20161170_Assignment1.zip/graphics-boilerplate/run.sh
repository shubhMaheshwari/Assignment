rm -rf build 
mkdir build 
cd build 
cmake .. 
make  
./graphics_asgn1