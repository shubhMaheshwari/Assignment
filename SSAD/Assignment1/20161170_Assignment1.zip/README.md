Welcome to BomberMan!!!

Execution :
	python3 game.py

Controls:

	b : Drop Bomb

	a : Move Left
	w : Move Up
	s : Move Down
	d : Move Right

	p : pause
	q : Quit
	p : pause
	r : Kill yourself


Levels : 
	As the levels increase the number of enemies increase



Bomberman  : [^^]
			  ][

Bomb :
	Bomb countdowns as follows
	[4 4] -> [3 3] -> [2 2] -> [1 1] -> ^^^^ 
	[4 4]    [3 3] 	  [2 2]	   [1 1]    ^^^^


Enemy 1 : 
			[]
		   /||\
	Moves horizontally or vertically
	50 points to kill 

Enemy 2 : 
			**	
		   ||||

	Tries to catch the bomberman
	100 points to kill 


