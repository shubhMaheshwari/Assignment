class CreateGames < ActiveRecord::Migration[5.1]
  def change
    create_table :games do |t|
      t.integer :user
      t.boolean :state
      t.integer :questions_list
      t.string :genre
      t.string :subgenre
      t.integer :score

      t.timestamps
    end
  end
end
