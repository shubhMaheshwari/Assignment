class CreateOptions < ActiveRecord::Migration[5.1]
  def change
    create_table :options do |t|
      t.text :a
      t.text :b
      t.text :c
      t.text :d
      t.boolean :is_a
      t.boolean :is_b
      t.boolean :is_c
      t.boolean :is_d

      t.timestamps
    end
  end
end
