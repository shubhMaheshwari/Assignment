class Question < ApplicationRecord
	# validates :question, :genre, :sub_genre, presence: true
	has_one :option 
	belongs_to :game 

end
