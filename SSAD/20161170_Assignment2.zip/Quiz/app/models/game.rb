class Game < ApplicationRecord
	has_one :user
	has_one :question
end
