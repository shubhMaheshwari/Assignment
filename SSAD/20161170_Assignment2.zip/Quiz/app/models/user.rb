class User < ApplicationRecord
  # validates :name, :email, presence: true	
  # validates :encrypted_password, length: {minimum: 6}	

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  belongs_to :game

  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable



end
