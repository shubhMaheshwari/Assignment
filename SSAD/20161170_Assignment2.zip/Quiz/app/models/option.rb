class Option < ApplicationRecord
end
