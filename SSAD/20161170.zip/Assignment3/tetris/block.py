class block(object):
    zPiece = [
            [1,1,0],
            [0,1,1]
            ]
    iPiece = [
            [1,1,1,1]
            ]
    sPiece = [
            [0,1,1],
            [1,1,0]
            ]
    oPiece = [
                [1,1],
                [1,1]
            ]
    tPiece = [
                [0,1,0],
                [1,1,1]
            ]
    jPiece = [
                [0,0,1],
                [1,1,1]
            ]
    lPiece = [
                [1,0,0],
                [1,1,1]
            ]
    tetrisPieces = [zPiece,iPiece,sPiece,oPiece,tPiece,jPiece,lPiece]
